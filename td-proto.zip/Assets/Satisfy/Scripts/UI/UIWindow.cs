﻿using System;
using System.Collections;
using System.Collections.Generic;

using UnityEngine;

namespace Satisfy.UI
{
    public class UIWindow : MonoBehaviour
    {
        protected GameObject content;

        protected virtual void Awake()
        {
            gameObject.SetActive(true);
            content = transform.GetChild(0).gameObject;
        }

        public virtual void Show()
        {
            content.SetActive(true);
        }

        public virtual void Hide()
        {
            content.SetActive(false);
        }
    }
}