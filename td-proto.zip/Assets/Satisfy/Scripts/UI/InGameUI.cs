﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Satisfy.Utility;
using TMPro;
using System;
using UniRx;
using System.Linq;
using DG.Tweening;
using Satisfy.Variables;
using Satisfy.Attributes;

namespace Satisfy.UI
{
    public class InGameUI : UIWindow
    {
        [SerializeField, Variable_R] IntVariable completedLevels;
        [SerializeField, Variable_R] IntVariable collectedCurrency;
        [SerializeField, Editor_R] Slider progressBar;
        [SerializeField, Editor_R] TextMeshProUGUI currentLevelValue;
        [SerializeField, Editor_R] TextMeshProUGUI nextLevelValue;
        [SerializeField, Editor_R] TextMeshProUGUI moneyText;
        [SerializeField, Editor_R] TextMeshProUGUI[] perfectTexts;
        [SerializeField, Editor_R] TextMeshProUGUI[] badTexts;

        List<TextMeshProUGUI> unusedPerfectTexts;
        List<TextMeshProUGUI> unusedBadTexts;
        Camera mainCam;
        float startYGood;
        float startYBad;
        float startX;
        Vector3 startPosGood;
        Vector3 startPosBad;

        public override void Hide()
        {
            base.Hide();
        }

        void Start()
        {
            startYGood = perfectTexts[0].transform.localPosition.y;
            startYBad = badTexts[0].transform.localPosition.y;
            startX = perfectTexts[0].transform.localPosition.x;
            startPosGood = perfectTexts[0].transform.localPosition;
            startPosBad = badTexts[0].transform.localPosition;

            unusedPerfectTexts = new List<TextMeshProUGUI>(perfectTexts);
            unusedBadTexts = new List<TextMeshProUGUI>(badTexts);

            mainCam = Camera.main;

            foreach (var x in perfectTexts)
            {
                x.gameObject.SetActive(false);
            }

            foreach (var x in badTexts)
            {
                x.gameObject.SetActive(false);
            }

            Hide();

            var totalMoney = 0;

            collectedCurrency.PublishedValue.Do(x =>
                {
                    totalMoney += (int)x;
                    moneyText.text = $"+{totalMoney}";
                })
                .Throttle(TimeSpan.FromSeconds(0.5f))
                .Subscribe(x => { totalMoney = 0; }).AddTo(this);

            // if (finger != null)
            // {
            //     Observable.EveryGameObjectUpdate().Where(x => Input.GetMouseButtonDown(0))
            //        .Subscribe(_ => { finger.SetActive(true); }).AddTo(this);

            //     Observable.EveryGameObjectUpdate().Where(x => Input.GetMouseButtonUp(0))
            //        .Subscribe(_ => { finger.SetActive(false); }).AddTo(this);
            // }
        }

        void HandleTextAnimation(GameObject text, Transform textPoint, bool isGood)
        {
            text.transform.DOLocalMoveY(startYGood, 0f);
            text.transform.DOKill(true);

            if (textPoint != null)
                text.transform.parent.position = mainCam.WorldToScreenPoint(textPoint.position + Vector3.up * 12f);
            text.SetActive(true);

            text.transform.DORotate(Vector3.zero, 0.2f).From(new Vector3(0, 90, -50))
                .SetEase(Ease.InOutBack);

            text.transform.DOLocalMoveY(startYGood + 636, 1f).From(startYGood)
                .OnComplete(() => text.transform.DOLocalMoveY(startYGood, 0f));

            text.transform.DOScale(1, 0.3f).From(0.1f)
                .SetEase(Ease.InOutBack)
                .OnComplete(() =>
                {
                    text.transform.DOScale(0, 0.2f).SetDelay(0.3f).SetEase(Ease.InOutBack);
                    text.transform.DORotate(new Vector3(0, 0, -20), 0.2f).SetDelay(0.3f).SetEase(Ease.InOutBack);
                });
        }

        void ShowText(bool good)
        {
            var textList = good ? perfectTexts : badTexts;
            var unusedTextList = good ? unusedPerfectTexts : unusedBadTexts;

            textList.Where(f => f.gameObject.activeSelf)?.First().gameObject.SetActive(false);

            if (unusedTextList.Count == 0)
                unusedTextList.AddRange(textList);

            var text = unusedTextList.GetRandomItem(out var index).gameObject;
            unusedTextList.RemoveAt(index);

            HandleTextAnimation(text, null, good);
        }

        public void ShowPerfectText() => ShowText(true);
        public void ShowBadText() => ShowText(false);

        public override void Show()
        {
            SetProgressBar();
            base.Show();
        }

        void SetProgressBar()
        {
            progressBar.value = 0;
            progressBar.minValue = 0;
            progressBar.maxValue = 0.9f;

            currentLevelValue.text = $"{completedLevels.Value}";
            nextLevelValue.text = $"{completedLevels.Value + 1}";
        }
    }
}