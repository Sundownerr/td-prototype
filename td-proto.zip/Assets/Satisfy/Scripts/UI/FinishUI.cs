﻿using UniRx;
using UnityEngine;
using TMPro;
using DG.Tweening;
using Satisfy.Variables;
using Satisfy.Attributes;

namespace Satisfy.UI
{
    public class FinishUI : UIWindow
    {

        [SerializeField, Variable_R] IntVariable completedLevels;
        [SerializeField, Variable_R] PlayerScoreVariable playerScoreMessage;
        [SerializeField, Variable_R] IntVariable loopFromLevel;
        [SerializeField, Editor_R] TextMeshProUGUI totalCoins;
        [SerializeField, Editor_R] TextMeshProUGUI levelValue;

        void Start()
        {
            Hide();

            var currentCoins = 0;

            playerScoreMessage.ObserveEveryValueChanged(x => x.Value.Total)
                .Subscribe(x =>
                {
                    DOTween.Kill(currentCoins);
                    DOTween.To(() => currentCoins, t => currentCoins = t, (int)x, 0.3f)
                            .OnUpdate(() => { totalCoins.text = $"{Mathf.Round(currentCoins)}"; });
                }).AddTo(this);
        }

        public void HandleTexts()
        {
            // Debug.Log(playerScoreMessage.Value.Total);
            // totalCoins.text = $"{((int)(playerScoreMessage.Value.Total)).ToStringShort()}";

            if (completedLevels.Value - loopFromLevel.Value > 0)
                levelValue.text = $"{completedLevels.Value - loopFromLevel.Value}";
        }
    }
}