﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UniRx;
using System;
using UnityEngine.UI;
using DG.Tweening;
using Satisfy.Variables;
using Sirenix.OdinInspector;
using Satisfy.Attributes;

namespace Satisfy.UI
{
    public class PopupUI : UIWindow
    {
        [Serializable]
        public class Unlock
        {
            [SerializeField] int level;
            [SerializeField] Sprite image;

            public int Level => level;
            public Sprite Image => image;
        }
        [SerializeField, Variable_R] IntVariable completedLevels;
        [SerializeField, Variable_R] Variable menuShowEnded;
        [SerializeField, Editor_R] GameObject unlockObject;
        [SerializeField, Editor_R] Image unlockImage;
        [SerializeField, Editor_R] Button continueButton;

        [SerializeField, Editor_R] List<Unlock> unlocks;

        [Button]
        void TestShow() { Show(); }

        void Start()
        {
            // content.SetActive(false);
            completedLevels.ObserveEveryValueChanged(x => x.Value).Skip(1)
                .Select(x => unlocks.Find(u => u.Level == x))
                .Where(x => x != null)
                .Do(x => unlockImage.sprite = x.Image)
                .Subscribe(x =>
                {
                    menuShowEnded.Published.First()
                        .Subscribe(m => Show());
                }).AddTo(this);

        }

        public override void Show()
        {
            continueButton.interactable = true;

            base.Show();
            unlockObject.transform.DOScale(1, 0.3f).SetEase(Ease.OutBack).From(0.01f);
            continueButton.transform.DOPunchScale(Vector3.one * 0.05f, 1f, 1, 0.1f).SetLoops(-1, LoopType.Incremental);
        }

        public override void Hide()
        {
            continueButton.interactable = false;
            continueButton.transform.DOKill(true);

            unlockObject.transform.DOScale(0.01f, 0.2f).SetEase(Ease.InBack)
                .OnComplete(() =>
                {
                    base.Hide();
                });
        }
    }
}