﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Satisfy.UI
{
    public class LevelProgress : MonoBehaviour
    {
        [SerializeField] GameObject completed;
        [SerializeField] GameObject current;
        [SerializeField] GameObject notCompleted;

        public void SetCompleted()
        {
            current.SetActive(false);
            notCompleted.SetActive(false);
            completed.SetActive(true);
        }

        public void SetNotCompleted()
        {
            current.SetActive(false);
            notCompleted.SetActive(true);
            completed.SetActive(false);
        }

        public void SetCurrent()
        {
            current.SetActive(true);
            notCompleted.SetActive(false);
            completed.SetActive(false);
        }
    }
}