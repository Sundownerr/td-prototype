﻿using System;
using UniRx;
using UnityEngine;
using TMPro;
using DG.Tweening;
using Satisfy.Variables;
using Satisfy.Attributes;

namespace Satisfy.UI
{
    public class MenuUI : UIWindow
    {
        [SerializeField, Variable_R] IntVariable completedLevels;
        [SerializeField, Variable_R] IntVariable loopFromLevel;
        [SerializeField, Variable_R] Variable menuShowEnded;
        [SerializeField, Variable_R] Variable levelDecreased;
        [SerializeField, Editor_R] GameObject skinsButton;
        [SerializeField, Editor_R] GameObject levelProgressBar;
        [SerializeField, Editor_R] TextMeshProUGUI levelValueText;
        [SerializeField, Editor_R] CanvasGroup canvas;
        [SerializeField, Editor_R]
        LevelProgress[] levelProgresses;

        void Start()
        {
            var levelTextParent = levelValueText.transform.parent;

            levelValueText.text = $"{completedLevels.Value}";

            HandleLevelProgress();
            Show();

            levelDecreased.Published.Subscribe(x => Show()).AddTo(this);

            completedLevels.ObserveEveryValueChanged(x => x.Value)
                .Do(x =>
                {
                    levelProgressBar.gameObject.SetActive(false);
                    HandleVisibility();
                })
                .Where(x => x > loopFromLevel.Value)
                .Subscribe(x =>
                {
                    HandleLevelProgress();
                    levelValueText.text = $"{x - loopFromLevel.Value}";
                })
                .AddTo(this);

            void HandleLevelProgress()
            {
                foreach (var x in levelProgresses)
                {
                    x.SetNotCompleted();
                    x.transform.DOKill(true);
                }

                var curLevelIndex = (completedLevels.Value - (loopFromLevel.Value + 1)) % levelProgresses.Length;

                if (curLevelIndex < 0)
                    return;

                for (int i = 0; i < curLevelIndex; i++)
                    levelProgresses[i].SetCompleted();

                levelProgresses[curLevelIndex].SetCurrent();

                levelProgresses[curLevelIndex].transform.DOPunchScale(Vector3.one * 0.1f, 2f, 1, 0.5f)
                    .SetLoops(-1, LoopType.Incremental);
            }

            void HandleVisibility()
            {
                var activate = completedLevels.Value > loopFromLevel.Value;

                if (skinsButton.gameObject.activeSelf)
                    skinsButton.gameObject.SetActive(activate);
            }
        }

        public override void Show()
        {
            GC.Collect();
            base.Show();
            DOTween.To(() => canvas.alpha, sttr => canvas.alpha = sttr, 1, 0.2f)
                .OnComplete(() => { menuShowEnded.Publish(); });
        }

        public override void Hide()
        {
            DOTween.To(() => canvas.alpha, sttr => canvas.alpha = sttr, 0, 0.001f)
                .OnComplete(() => { base.Hide(); });
        }
    }
}