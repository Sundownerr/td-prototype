﻿using UnityEngine;
using TMPro;

namespace Satisfy.UI
{
    public class LevelUI : UIWindow
    {
        [SerializeField] TextMeshProUGUI levelText;
        [SerializeField] Animator animator;


        void Start()
        {
            // animator = GetComponent<Animator>();
            // SetLevelText();
            // Hide();

            // MessageBroker.Default.Receive<UI>()
            //     .Where(x => x == UI.FinishContinue)


            // UIManager.DoAfterValidate(() =>
            // {
            //     UIManager.Get<FinishUI>().ContinuePressed += () =>
            //     {
            //         SetLevelText();
            //         Hide();
            //         animator.Play("Hide");
            //     };

            //     UIManager.Get<MenuUI>().PlayPressed += () => { Show(); };

            //     UIManager.Get<GameOverUI>().RestartPressed += () => { Show(); };
            // });

            // LevelManager.PlayerDied += () => { Hide(); };

            // LevelManager.PlayerFinished += () => { animator.Play("Show"); };

            // void SetLevelText()
            // {
            //     levelText.text = $"Level {DataController.PlayerData.CompletedLevelsCount}";
            // }
        }
    }
}