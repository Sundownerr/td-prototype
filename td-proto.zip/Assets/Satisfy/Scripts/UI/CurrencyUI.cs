﻿using UnityEngine;
using TMPro;
using UniRx;
using DG.Tweening;
using System;
using Satisfy.Variables;
using Satisfy.Attributes;
using Satisfy.Utility;

namespace Satisfy.UI
{
    public class CurrencyUI : UIWindow
    {

        [SerializeField, Variable_R] FloatVariable currency;
        [SerializeField, Editor_R] TextMeshProUGUI coinsValue;
        // [SerializeField, MessageReference]

        void Start()
        {

            var coins = (int)currency.Value;

            UpdateCoins();

            currency.ObserveEveryValueChanged(x => x.Value)
                .Delay(TimeSpan.FromSeconds(0.5f))
                .Subscribe(x => { UpdateCoins(); }).AddTo(this);

            void UpdateCoins()
            {
                DOTween.To(() => coins, t => coins = t, (int)(currency.Value), 0.5f)
                    .OnUpdate(() => coinsValue.text = $"{coins.ToStringShort()}");
            }


        }
    }
}