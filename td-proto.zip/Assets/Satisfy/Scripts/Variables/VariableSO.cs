﻿using System;
using System.Collections;
using System.Collections.Generic;
using Sirenix.OdinInspector;
using UniRx;
using UnityEngine;

namespace Satisfy.Variables
{
    [Serializable]
    public class VariableSO<T> : Variable
    {
        public IObservable<T> PublishedValue => Published.Select(x => value);
        public Subject<Pair<T>> Changed { get; private set; } = new Subject<Pair<T>>();

        [SerializeField, HideLabel] protected T value;
        public T Value => value;

        public virtual void SetValue(T value)
        {
            var pair = new Pair<T>(this.value, value);

            this.value = value;

            Changed.OnNext(pair);

            if (debug) Debug.Log($"[ changed ]  {name} = {value}", this);

        }

        public void SetValueAndPublish(T value)
        {
            SetValue(value);
            this.Publish();
        }

        [Button("Fake Changed", ButtonSizes.Medium), GUIColor(0.85f, 1, 0.85f), PropertyOrder(-3), HideInInlineEditors, HideInEditorMode]
        public void FakeChanged() => SetValue(value);
    }
}