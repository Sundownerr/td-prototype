using System;
using UnityEngine;
namespace Satisfy.Variables
{
    [CreateAssetMenu(fileName = "Vector2", menuName = "Variables/Vector2")]
    [Serializable]
    public class Vector2Variable : VariableSO<Vector2>
    {

    }
}