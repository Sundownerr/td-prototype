using System;
using UnityEngine;

namespace Satisfy.Variables
{
    [CreateAssetMenu(fileName = "Transform", menuName = "Variables/Transform")]
    [Serializable]
    public class TransformVariable : VariableSO<Transform>
    {

    }
}