using System;
using UnityEngine;

namespace Satisfy.Variables
{
    [CreateAssetMenu(fileName = "Variable", menuName = "Variables/Variable")]
    [Serializable]
    public class VariableVariable : VariableSO<Variable>
    {

    }
}