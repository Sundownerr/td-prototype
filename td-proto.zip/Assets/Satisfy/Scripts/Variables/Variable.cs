﻿using System;
using System.Collections;
using System.Collections.Generic;
using Satisfy.Attributes;
using Sirenix.OdinInspector;
using UniRx;
using UnityEngine;

namespace Satisfy.Variables
{
    [CreateAssetMenu(fileName = "Message", menuName = "Variables/Base")]
    [Serializable]
    public class Variable : ScriptableObject
    {
        public Subject<Variable> Published { get; private set; } = new Subject<Variable>();

        [SerializeField, Tweakable, HideInInlineEditors] protected bool debug;

        [Button("Publish", ButtonSizes.Medium), GUIColor(0.85f, 1, 0.85f), PropertyOrder(-3), HideInInlineEditors, HideInEditorMode]
        public void Publish()
        {
            Published.OnNext(this);

            if (debug)
                Debug.Log($"[ published ]  {name}", this);
        }
    }
}