using System;
using UnityEngine;
// using UnityEngine.AddressableAssets;
// using UnityEngine.ResourceManagement;

namespace Satisfy.Variables
{
    // [Serializable, CreateAssetMenu(fileName = "AssetRefList", menuName = "Lists/Asset Reference")]
    // public class AssetReferenceList : ListSO<AssetReference>
    // {

    // }
}
