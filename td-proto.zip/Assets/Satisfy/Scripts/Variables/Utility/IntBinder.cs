using Satisfy.Variables;

namespace Satisfy.Utility
{
    public class IntBinder : Binder<IntVariable, int>
    {

    }
}