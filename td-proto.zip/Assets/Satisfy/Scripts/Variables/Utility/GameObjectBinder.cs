using Satisfy.Variables;
using UnityEngine;

namespace Satisfy.Utility
{
    public class GameObjectBinder : Binder<GameObjectVariable, GameObject>
    {

    }
}