﻿using System;
using System.Collections;
using System.Collections.Generic;
using Satisfy.Variables;
using Sirenix.OdinInspector;
using UniRx;
using UnityEngine;
using UnityEngine.Events;

namespace Satisfy.Variables
{

    public class OnVariableChanged : MonoBehaviour
    {
        [ListDrawerSettings(ShowIndexLabels = false, ShowItemCount = false, Expanded = true, DraggableItems = false), LabelText(" ")]
        [GUIColor(1, 1, 0.95f), SerializeField] VariableAction[] list;

        void Start()
        {
            foreach (var valueActions in list)
            {
                foreach (var variable in valueActions.Message)
                {
                    (variable as IntVariable).Changed
                        .Subscribe(_ =>
                        {
                            valueActions.Action?.Invoke();
                        }).AddTo(this);
                }
            }
        }
    }
}