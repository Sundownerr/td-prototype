﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using Sirenix.OdinInspector;
using DG.Tweening;
using UniRx;
using System.Linq;
using System.Reflection;
using Satisfy.Variables;
using System;

namespace Satisfy.Utility
{
    [HideMonoScript]
    public class Binder<TVariable, VariableType> : MonoBehaviour where TVariable : VariableSO<VariableType>
    {
        public enum SetType { SetProperty, SetVariable }

        [SerializeField, HideLabel, LabelWidth(15)]
        SetType setType = SetType.SetVariable;

        [SerializeField, HorizontalGroup("1"), LabelText("@object2Type"), OnValueChanged(nameof(UpdateProperties))]
        UnityEngine.Object target;

        [SerializeField, HorizontalGroup("1"), ValueDropdown(nameof(members)), HideLabel, LabelWidth(5)]
        string selectedMember;

        [SerializeField, LabelText("@object1Type"), OnValueChanged(nameof(UpdateProperties))]
        TVariable variable;

        static BindingFlags flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

        ValueDropdownList<string> members = new ValueDropdownList<string>();
        string object1Type => setType == SetType.SetVariable ? "To" : "From";
        string object2Type => setType == SetType.SetProperty ? "To" : "From";

        void Start()
        {
            var property = target.GetType().GetField(selectedMember, flags);
            var field = target.GetType().GetProperty(selectedMember, flags);

            if (property != null)
            {
                Observable.EveryUpdate()
                    .Subscribe(_ =>
                    {
                        if (setType == SetType.SetVariable)
                            variable.SetValue((VariableType)property.GetValue(target));
                        else
                            property.SetValue(target, variable.Value);
                    }).AddTo(this);
            }

            if (field != null)
            {
                Observable.EveryUpdate()
                    .Subscribe(_ =>
                    {
                        if (setType == SetType.SetVariable)
                            variable.SetValue((VariableType)field.GetValue(target));
                        else
                            field.SetValue(target, variable.Value);
                    }).AddTo(this);
            }
        }

        [Button]
        void UpdateProperties()
        {
            selectedMember = "";
            members.Clear();

            if (target == null || variable == null)
                return;

            target.GetType().GetProperties(flags).ToList()
                .ForEach(x =>
                {
                    if (x.PropertyType == variable.Value.GetType())
                        members.Add(x.Name, x.Name);
                });

            target.GetType().GetFields(flags).ToList()
                .ForEach(x =>
                {
                    if (x.FieldType == variable.Value.GetType())
                        members.Add(x.Name, x.Name);
                });

            if (members.Count > 0)
                selectedMember = members[0].Text;

        }
    }
}