using Satisfy.Variables;

namespace Satisfy.Utility
{
    public class FloatBinder : Binder<FloatVariable, float>
    {

    }
}