﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.Events;
using UniRx;
using Sirenix.OdinInspector;
using UniRx.Triggers;
using Satisfy.Variables;
using Satisfy.Attributes;
#if UNITY_EDITOR
using UnityEditor;
#endif
namespace Satisfy.Entities
{
    public class Triggerable : MonoBehaviour
    {
        public Subject<int> Triggered { get; protected set; } = new Subject<int>();
    }

    [HideMonoScript]
    public class TriggerObject : Triggerable
    {
        public Subject<Collider> Entered { get; private set; } = new Subject<Collider>();
        public Subject<Collider> Exit { get; private set; } = new Subject<Collider>();
        public IReadOnlyCollection<GameObject> EnteredEntities => enteredEntities;

        public Collider Collider => col;

        [ListDrawerSettings(Expanded = true, DraggableItems = false, ShowIndexLabels = false)]
        [SerializeField, Tweakable, LabelText("Tags")] List<string> filterTag = new List<string>() { "Player" };
        [SerializeField, Tweakable] GameObjectVariable enteredEntityVariable;
        [SerializeField, Tweakable] bool disableTriggerOnEnter;
        [SerializeField, Tweakable] bool destroyEnteredObject;
        [SerializeField, Tweakable, LabelText("Enter")] UnityEvent actionOnTriggerEnter;
        [SerializeField, Tweakable, LabelText("Exit")] UnityEvent actionOnTriggerExit;
        [SerializeField, Debugging] bool debug;
        [SerializeField, Debugging] Color debugColor = new Color(0.3f, 1f, 0.3f, 0.15f);
        [SerializeField, Debugging] Color debugOutlineColor = new Color(0.1f, 0.1f, 0.1f, 0.05f);

        [SerializeField, ShowIf("@debug == true"), ReadOnly]
        [ListDrawerSettings(Expanded = true)]
        List<GameObject> enteredEntities = new List<GameObject>();
        Collider col;

        void OnValidate()
        {
            col = GetComponent<Collider>();

            if (col == null)
                gameObject.AddComponent<BoxCollider>().isTrigger = true;
            // else
            //     col.isTrigger = true;
        }

        void OnDrawGizmos()
        {
            if (col == null)
                return;

            if (col is BoxCollider box)
            {
                Gizmos.color = debugColor;
                Gizmos.matrix = Matrix4x4.TRS(transform.TransformPoint(box.center), transform.rotation, Vector3.Scale(transform.lossyScale, box.size));

                Gizmos.DrawCube(Vector3.zero, Vector3.one);

                Gizmos.color = debugOutlineColor;
                Gizmos.DrawWireCube(Vector3.zero, Vector3.one);
            }
        }

        void Start()
        {
            if (col == null)
            {
                col = GetComponent<Collider>();

                if (col == null)
                    gameObject.AddComponent<BoxCollider>().isTrigger = true;
                // else
                //     col.isTrigger = true;
            }

            var entered = this.OnTriggerEnterAsObservable()
                .Where(x => x != null)
                .Where(col => filterTag.Find(tag => col.CompareTag(tag)) != null)
                .Where(col => !enteredEntities.Contains(col.gameObject));

            var exit = this.OnTriggerExitAsObservable()
                .Where(x => x != null)
                .Where(col => filterTag.Find(tag => col.CompareTag(tag)) != null)
                .Where(col => enteredEntities.Contains(col.gameObject));

            entered.Subscribe(x =>
            {
                Entered.OnNext(x);
                enteredEntities.Add(x.gameObject);

                if (enteredEntityVariable != null)
                    enteredEntityVariable.SetValueAndPublish(x.gameObject);

                PerformEnterAction();

                if (destroyEnteredObject)
                    Destroy(x.gameObject);

                if (disableTriggerOnEnter)
                    col.enabled = false;

                Triggered.OnNext(1);
#if UNITY_EDITOR
                if (debug) Debug.Log($"{x.gameObject.name} entered {name}");
#endif
            }).AddTo(this);

            exit.Subscribe(x =>
            {
                Exit.OnNext(x);
                enteredEntities.Remove(x.gameObject);
                PerformExitAction();
#if UNITY_EDITOR
                if (debug) Debug.Log($"{x.gameObject.name} exit {name}");
#endif
            }).AddTo(this);
        }

        [Button("Enter Action", ButtonSizes.Large), PropertyOrder(-1), GUIColor(0.85f, 1, 0.85f), HideInEditorMode]
        public void PerformEnterAction() { actionOnTriggerEnter?.Invoke(); }

        [Button("Exit Action", ButtonSizes.Large), PropertyOrder(-1), GUIColor(0.85f, 1, 0.85f), HideInEditorMode]
        public void PerformExitAction() { actionOnTriggerExit?.Invoke(); }

        public void ClearEntities() { enteredEntities.Clear(); }

#if UNITY_EDITOR
        [MenuItem("GameObject/3D Object/Trigger")]
        static void Create()
        {
            if (!Application.isPlaying)
            {
                var trigger = new GameObject();
                trigger.AddComponent<TriggerObject>();
                trigger.gameObject.name = "Trigger";
                trigger.transform.SetParent(Selection.activeGameObject.transform);
                trigger.transform.localPosition = Vector3.zero;
                Selection.activeGameObject = trigger.gameObject;
            }
        }
#endif
    }

    [Serializable]
    public class TransformEvent : UnityEvent<Transform> { }

    [Serializable]
    public class RigidbodyEvent : UnityEvent<Rigidbody> { }
}