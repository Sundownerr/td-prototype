using System;
using Satisfy.Attributes;
using Satisfy.Variables;
using Sirenix.OdinInspector;
using UniRx;
using UnityEngine;

namespace Satisfy.Managers
{
    [CreateAssetMenu(fileName = "CurrencyManagerSO", menuName = "Managers/Currency ")]
    [Serializable]
    public class CurrencyManagerSO : ScriptableObjectSystem
    {
        [SerializeField, Debugging, LabelWidth(40)] bool debug;
        [SerializeField, VariableExpanded_R] IntVariable gameCurrency;
        [SerializeField, Variable_R] PlayerScoreVariable playerScore;
        [SerializeField, Variable_R] FloatVariable finishMultReceived;
        [SerializeField, Variable_R] IntVariable collectedCurrency;
        [SerializeField, Variable_R] Variable[] resetScoreEvents;

        public override void Initialize()
        {
            playerScore.PublishedValue.Subscribe(x =>
            {
                gameCurrency.IncreaseBy((int)x.Total);

#if UNITY_EDITOR
                if (debug)
                    Debug.Log($"Currency|    +{x.Total} , total: {gameCurrency.Value}");
#endif
            });

            finishMultReceived.PublishedValue.Subscribe(mult =>
            {
                playerScore.Value.finishMults = mult;
                playerScore.Publish();

#if UNITY_EDITOR
                if (debug)
                    Debug.Log($"Currency|    Mults = x{mult}");
#endif
            });

            collectedCurrency.PublishedValue.Subscribe(x =>
            {
                playerScore.Value.coins += x;

#if UNITY_EDITOR
                if (debug)
                    Debug.Log($"Currency|    Collected {x}");
#endif
            });

            foreach (var x in resetScoreEvents)
            {
                x.Published.Subscribe(_ =>
                {
                    ResetScore();
                });
            }
        }

        public bool CheckCanBuy(float cost) => gameCurrency.Value >= cost;

        public void ResetScore()
        {
            playerScore.Value.Reset();

#if UNITY_EDITOR
            if (debug)
                Debug.Log($"Currency|    Reset score");
#endif
        }
    }
}
