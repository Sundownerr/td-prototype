﻿using System.Collections;
using Satisfy.Variables;
using Satisfy.Utility;
using Sirenix.OdinInspector;
using UnityEngine;

namespace Satisfy.Managers
{
    public abstract class ScriptableObjectSystem : ScriptableObject
    {
        public abstract void Initialize();
    }
}
