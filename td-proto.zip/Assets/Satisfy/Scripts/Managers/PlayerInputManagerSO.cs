﻿using System;
using Satisfy.Attributes;
using Satisfy.Variables;
using UniRx;
using UnityEngine;

namespace Satisfy.Managers
{
    [CreateAssetMenu(fileName = "PlayerInputManagerSO", menuName = "Managers/Player Input")]
    [Serializable]
    public class PlayerInputManagerSO : ScriptableObjectSystem
    {
        // [Serializable]
        // public class NewInputAction
        // {
        //     public InputAction input;
        //     public UnityEvent action;
        // }
        [SerializeField, Variable_R] Variable tap;
        [SerializeField, Variable_R] BoolVariable hold;
        [SerializeField, Variable_R] Variable release;
        [SerializeField, Variable_R] Vector2Variable pointerStartPos;
        [SerializeField, Variable_R] Vector2Variable pointerCurrentPos;
        [SerializeField, Variable_R] Vector2Variable pointerDeltaPos;
        [SerializeField, Tweakable] float dpi = 100;
        // [ListDrawerSettings(Expanded = true, ShowIndexLabels = false)]
        // [SerializeField, Tweakable] List<NewInputAction> inputs;

        public override void Initialize()
        {
            var update = Observable.EveryUpdate();

            // inputs.ForEach(x => x.input.Enable());
            // inputs.ForEach(i => i.input.ObserveEveryValueChanged(x => x.triggered)
            //     .Where(x => x == true)
            //     .Subscribe(_ =>
            //     {
            //         i.action?.Invoke();
            //     })
            // );

            var delta = Vector2.zero;

            update.Where(_ => Input.GetMouseButtonDown(0))
                .Subscribe(_ =>
                {
                    pointerStartPos.SetValue(Input.mousePosition);
                    pointerCurrentPos.SetValue(Input.mousePosition);
                    tap.Publish();
                    hold.SetValueAndPublish(true);
                });

            update.Where(_ => Input.GetMouseButtonUp(0))
                .Subscribe(_ =>
                {
                    hold.SetValueAndPublish(false);
                    release.Publish();
                });

            update.Where(_ => hold.Value == true)
                .Subscribe(_ =>
                {
                    pointerDeltaPos.SetValue(new Vector2(Input.GetAxis("Mouse X") * dpi,
                                                        Input.GetAxis("Mouse Y") * dpi));
                    pointerCurrentPos.SetValue(Input.mousePosition);
                });

            // var pointer = Pointer.current;


            // update.Where(_ => pointer.press.wasPressedThisFrame)
            //     .Subscribe(_ =>
            //     {
            //         pointerStartPos.Value = pointer.position.ReadValue();
            //         pointerCurrentPos.Value = pointer.position.ReadValue();
            //         tap.Publish();
            //         hold.SetValueAndPublish(true);
            //     });

            // update.Where(_ => pointer.press.wasReleasedThisFrame)
            //     .Subscribe(_ =>
            //     {
            //         hold.SetValueAndPublish(false);
            //         release.Publish();
            //     });

            // update.Where(_ => hold.Value == true)
            //     .Subscribe(_ =>
            //     {
            //         pointerDeltaPos.Value = pointer.delta.ReadValue();
            //         pointerCurrentPos.Value = pointer.position.ReadValue();
            //     });
        }
    }
}