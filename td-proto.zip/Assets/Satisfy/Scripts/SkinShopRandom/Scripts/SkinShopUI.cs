﻿using System.Collections.Generic;
using System.Linq;
using Unity.Linq;
using UnityEngine;
using UnityEngine.UI;
using UniRx;
using TMPro;
using Satisfy.Variables;
using Satisfy.Attributes;
using Satisfy.SkinShop.Data;
using Satisfy.SkinShop.UI;
using Satisfy.Utility;
using Satisfy.Managers;
using Satisfy.Variables.Custom;

namespace Satisfy.SkinShop
{
    public class SkinShopUI : MonoBehaviour
    {

        public Subject<CategorySO> CategoryChanged = new Subject<CategorySO>();

        [SerializeField, Editor_R] CurrencyManagerSO currencyManagerSO;
        [SerializeField, Editor_R] SkinDataList unlockedSkins;
        [SerializeField, Editor_R] SkinDataList selectedSkins;
        [SerializeField, Variable_R] ItemSOVariable itemPurchased;
        [SerializeField, Variable_R] ItemSOVariable itemSelected;
        [SerializeField, Variable_R] FloatVariable currency;
        [SerializeField, Variable_R] IntVariable playerSkinCost;
        [SerializeField, Editor_R] Button buyButton;
        // [SerializeField, EditorReference] Button closeButton;
        [SerializeField, Editor_R] TextMeshProUGUI priceText;
        [SerializeField, Editor_R] Transform itemsWrapper;
        [SerializeField, Editor_R] Item itemPrefab;
        [SerializeField, Editor_R] ItemList itemList;
        [SerializeField, Editor_R] List<Category> categories;
        [SerializeField, Tweakable] bool unlockFirstSkinOfCategory = true;
        [SerializeField, Tweakable] float highlightDelay = 0.3f;

        List<Item> items = new List<Item>();
        List<Item> selectedItems = new List<Item>();
        ReactiveProperty<Category> selectedCategory = new ReactiveProperty<Category>();

        void Awake()
        {

            // тест категорий на одинаковость и на одинаковый индекс
            categories.ForEach(x =>
            {
                var sameCategory = categories.Find(c => c != x && x.CategorySO == c.CategorySO);
                var sameIndex = categories.Find(c => c != x && x.CategorySO.Index == c.CategorySO.Index);

                if (sameCategory != null)
                {
                    Debug.LogError($"ShopUI| categories have same SO ({x.CategorySO.name}): {x.gameObject.name} & {sameCategory.gameObject.name}");
                    Debug.Break();
                    return;
                }

                if (sameIndex != null)
                {
                    Debug.LogError($"ShopUI| categories have same index ({x.CategorySO.Index}) in SO: {x.gameObject.name} & {sameIndex.gameObject.name}");
                    Debug.Break();
                    return;
                }
            });
        }

        bool CheckCanActivateBuyButton()
        {
            var haveLockedItems = items.FindAll(i => i.gameObject.activeSelf).Find(i => i.IsLocked) != null;
            var canBuy = playerSkinCost.Value <= currency.Value;

            return canBuy && haveLockedItems;
        }

        void Start()
        {
            // Hide();

            // обновление кнопки купить при изменении цены на скин
            playerSkinCost.ObserveEveryValueChanged(x => x.Value)
                .Subscribe(x =>
                {
                    SetBuyPrice(x);
                    SetBuyInteractable(currencyManagerSO.CheckCanBuy(x));
                }).AddTo(this);

            // обновление кнопки купить при изменении кол-ва монет
            currency.ObserveEveryValueChanged(x => x.Value)
                .Subscribe(x =>
                {
                    SetBuyInteractable(playerSkinCost.Value <= currency.Value);
                }).AddTo(this);

            // обновление выбранной категории при клике на категорию
            categories.ForEach(x =>
            {
                x.Button.OnClickAsObservable()
                    .Subscribe(c => { selectedCategory.Value = x; }).AddTo(this);
            });

            // обновление отображаемых итемов при изменение категории
            selectedCategory.ObserveEveryValueChanged(x => x.Value)
                .Where(x => x != null)
                .Subscribe(x =>
                {
                    items.ForEach(i => i.gameObject.SetActive(false));
                    items.FindAll(i => i.ItemSO.Category == x.CategorySO).ForEach(i => i.gameObject.SetActive(true));

                    SetBuyInteractable(CheckCanActivateBuyButton());

                    CategoryChanged.OnNext(x.CategorySO);
                }).AddTo(this);

            // покупка итема
            buyButton.OnClickAsObservable()
                .Subscribe(c =>
                {
                    SetBuyInteractable(false);

                    var categoryItems = GetLockedCategoryItems(items);
                    var highlightedItem = GetNewHighlightedItem(categoryItems);

                    var highlightTimes = categoryItems.Count * 2;

                    HighlightItem();

                    void HighlightItem()
                    {
                        if (categoryItems.Count == 0)
                            categoryItems = GetLockedCategoryItems(items);

                        highlightedItem.SetHighlighted(false);
                        highlightedItem = GetNewHighlightedItem(categoryItems);

                        Get.Delay(highlightDelay).Subscribe(_ =>
                        {
                            highlightTimes--;

                            if (highlightTimes > 0)
                                HighlightItem();
                            else
                            {
                                highlightedItem.SetHighlighted(false).SetLocked(false);
                                SelectItem(highlightedItem);

                                itemPurchased.SetValueAndPublish(highlightedItem.ItemSO);

                                SetBuyInteractable(CheckCanActivateBuyButton());
                            }
                        }).AddTo(this);
                    }
                }).AddTo(this);


            // создание кнопок итемов

            foreach (var itemSO in itemList.List)
            {
                var isSelected = selectedSkins.List.Where(s => s.skinIndex == itemSO.Index).First() != null;
                var isLocked = unlockedSkins.List.Where(s => s.skinIndex == itemSO.Index).First() == null;

                var newItem = Instantiate(itemPrefab.gameObject, itemsWrapper).GetComponent<Item>()
                    .SetItemSO(itemSO)
                    .SetSelected(isSelected)
                    .SetLocked(isLocked)
                    .SetHighlighted(false);

                newItem.Button.OnClickAsObservable().Subscribe(c => { SelectItem(newItem); }).AddTo(newItem);

                items.Add(newItem);
            }

            SetBuyInteractable(CheckCanActivateBuyButton());

            // открытие первых скинов в категории при запуске
            Observable.IntervalFrame(1).Take(1).Subscribe(_ =>
            {
                if (unlockedSkins.List.Count == 0)
                    if (unlockFirstSkinOfCategory)
                        categories.ForEach(category =>
                        {
                            var firstItemOfCategory = items.Find(f => f.ItemSO.Category == category.CategorySO)
                                .SetLocked(false)
                                .SetSelected(true);

                            itemPurchased.SetValueAndPublish(firstItemOfCategory.ItemSO);
                        });
            }).AddTo(this);

            itemPurchased.PublishedValue
                .Subscribe(_ =>
                {
                    selectedItems = items.Where(x => x.IsSelected).ToList();
                }).AddTo(this);

            selectedItems = items.Where(x => x.IsSelected).ToList();
            selectedCategory.Value = categories[0];

            void SelectItem(Item item)
            {
                var prevSelectedItem = selectedItems.Find(s => s.ItemSO.Category == item.ItemSO.Category);
                selectedItems.Remove(prevSelectedItem);
                prevSelectedItem.SetSelected(false);

                item.SetSelected(true);
                selectedItems.Add(item);

                itemSelected.SetValueAndPublish(item.ItemSO);
            }

            Item GetNewHighlightedItem(List<Item> items, bool removeItem = true)
            {
                var item = items.GetRandomItem().SetHighlighted(true);

                if (removeItem)
                    items.Remove(item);

                return item;
            }

            List<Item> GetLockedCategoryItems(List<Item> items) =>
                items.FindAll(x => x.ItemSO.Category == selectedCategory.Value.CategorySO && x.IsLocked);
        }

        public SkinShopUI SetBuyPrice(float price)
        {
            priceText.text = $"{price}";

            return this;
        }

        public SkinShopUI SetBuyInteractable(bool interactable)
        {
            buyButton.interactable = interactable;

            return this;
        }
    }
}