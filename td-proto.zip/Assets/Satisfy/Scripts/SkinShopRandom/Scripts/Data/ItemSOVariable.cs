using System;
using Satisfy.SkinShop.Data;
using UnityEngine;

namespace Satisfy.Variables
{
    [CreateAssetMenu(fileName = "Item SO", menuName = "Variables/Item SO")]
    [Serializable]
    public class ItemSOVariable : VariableSO<ItemSO>
    {

    }
}