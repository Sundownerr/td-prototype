﻿using System;
using System.Collections;
using System.Collections.Generic;
using Sirenix.OdinInspector;
using UnityEngine;
using UnityEngine.UI;
using Satisfy.Attributes;

namespace Satisfy.SkinShop.Data
{
    [CreateAssetMenu(fileName = "Shop Item", menuName = "Data/Shop Item")]
    [Serializable]
    public class ItemSO : ScriptableObject
    {
        [SerializeField, ReadOnly] int index;
        public int Index { get => index; set => index = value; }

        [SerializeField, Editor_R] CategorySO category;
        [PreviewField(50, ObjectFieldAlignment.Left)]
        [SerializeField, Editor_R] Sprite icon;
        // [PreviewField(150, ObjectFieldAlignment.Left)]
        [SerializeField, Editor_R] GameObject model;

        public CategorySO Category => category;
        public Sprite Icon => icon;
        public GameObject Model => model;
    }
}