using System;
using Satisfy.SkinShop.Data;
using Sirenix.OdinInspector;
using UnityEngine;

namespace Satisfy.Variables
{
    [Serializable, CreateAssetMenu(fileName = "Item", menuName = "Lists/Item")]
    public class ItemList : ListSO<ItemSO>
    {

#if UNITY_EDITOR
        [Button]
        void UpdateIndecies()
        {
            for (int i = 0; i < list.Count; i++)
                list[i].Index = i;

            UnityEditor.EditorUtility.SetDirty(this);
        }

        [Button]
        void FillAllSkins()
        {
            // list = Ext.GetAllInstances<ItemSO>().ToList();
            UpdateIndecies();
        }
#endif
    }
}