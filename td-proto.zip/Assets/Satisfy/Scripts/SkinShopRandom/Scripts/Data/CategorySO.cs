﻿using System;
using UnityEngine;

namespace Satisfy.SkinShop.Data
{
    [CreateAssetMenu(fileName = "Category", menuName = "Data/Shop Category")]
    [Serializable]
    public class CategorySO : ScriptableObject
    {
        [SerializeField] int index;
        public int Index => index;
    }
}