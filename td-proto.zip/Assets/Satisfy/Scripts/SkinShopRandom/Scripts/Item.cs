﻿using Satisfy.Attributes;
using Satisfy.SkinShop.Data;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Satisfy.SkinShop.UI
{
    public class Item : MonoBehaviour
    {
        [SerializeField, Editor_R] Image icon;
        [SerializeField, Editor_R] Image lockImage;
        [SerializeField, Editor_R] Image selectedFrame;
        [SerializeField, Editor_R] Image highlightFrame;
        [SerializeField, Editor_R] Button button;
        [SerializeField, Tweakable] UnityEvent locked;
        [SerializeField, Tweakable] UnityEvent unlocked;
        [SerializeField, Tweakable] UnityEvent selected;
        [SerializeField, Tweakable] UnityEvent unselected;
        [SerializeField, Tweakable] UnityEvent highlighted;
        [SerializeField, Tweakable] UnityEvent unhighlighted;

        public ItemSO ItemSO { get; private set; }
        public Button Button => button;

        public bool IsSelected => selectedFrame.gameObject.activeSelf;
        public bool IsLocked => lockImage.gameObject.activeSelf;
        public bool IsHighlighted => highlightFrame.gameObject.activeSelf;

        public Item SetLocked(bool isLocked)
        {
            if (isLocked)
                locked?.Invoke();
            else
                unlocked?.Invoke();

            return this;
        }

        public Item SetSelected(bool isSelected)
        {
            if (isSelected)
                selected?.Invoke();
            else
                unselected?.Invoke();

            return this;
        }

        public Item SetHighlighted(bool isHighlighted)
        {
            if (isHighlighted)
                highlighted?.Invoke();
            else
                unhighlighted?.Invoke();

            return this;
        }

        public Item SetItemSO(ItemSO itemSO)
        {
            ItemSO = itemSO;
            icon.sprite = itemSO.Icon;

            return this;
        }
    }
}