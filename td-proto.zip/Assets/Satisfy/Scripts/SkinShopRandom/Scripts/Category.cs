﻿using System.Collections;
using System.Collections.Generic;
using Satisfy.SkinShop.Data;
using UnityEngine;
using UnityEngine.UI;

namespace Satisfy.SkinShop
{
    public class Category : MonoBehaviour
    {
        [SerializeField] CategorySO categorySO;
        [SerializeField] Button button;

        public CategorySO CategorySO => categorySO;
        public Button Button => button;
    }
}