﻿// using System.Collections;
// using System.Collections.Generic;
// using UnityEngine;
// using TMPro;
// using UnityEngine.UI;
// using UniRx;
// using DG.Tweening;
// using Satisfy.Managers;
// using System;
// using Satisfy.Messages;

// namespace Satisfy.UI
// {
//     public class UpgradeButton : MonoBehaviour
//     {
//         [SerializeField] TextMeshProUGUI levelText;
//         [SerializeField] TextMeshProUGUI costText;
//         [SerializeField] Image lockImage;
//         [SerializeField] GameObject adImage;
//         [SerializeField] Image coinImage;
//         [SerializeField] Button button;
//         [SerializeField] UpgradeMessage upgrade;
//         [SerializeField] int limit = 100;

//         public Button Button => button;
//         bool useRV => adImage.activeSelf;
//         int level;


//         void Start()
//         {
//             button.onClick.AddListener(() =>
//             {
//                 // if (useRV)
//                 // {
//                 //     if (!AdsManager.Instance.IsRVAvailable)
//                 //     {
//                 //         MessageBroker.Default.Publish(UI.NoInternetPressed);
//                 //         return;
//                 //     }

//                 //     upgrade.IsRV = useRV;
//                 //     SetWatchRV(false);
//                 // }

//                 MessageBroker.Default.Publish(upgrade);
//                 // upgrade.IsRV = false;

//                 transform.DOKill(true);
//                 transform.DOPunchScale(Vector3.one * 0.2f, 0.2f, 2, 0.3f);
//             });



//             IObservable<int> observableLevel = null;

//             if (upgrade.type == UpgradeMessage.Type.IceSize)
//             {
//                 observableLevel = DataController.PlayerData.Value.ObserveEveryValueChanged(x => x.IceSizeLevel);

//                 CurrencyManager.Instance.IceSizeCost.ObserveEveryValueChanged(x => x.Value)
//                     .Subscribe(x =>
//                     {
//                         SetLocked(!CurrencyManager.CheckCanBuy(x));
//                         SetCost(x);
//                     }).AddTo(this);
//             }
//             else if (upgrade.type == UpgradeMessage.Type.Speed)
//             {
//                 observableLevel = DataController.PlayerData.Value.ObserveEveryValueChanged(x => x.SpeedLevel);

//                 CurrencyManager.Instance.SpeedCost.ObserveEveryValueChanged(x => x.Value)
//                     .Subscribe(x =>
//                     {
//                         SetLocked(!CurrencyManager.CheckCanBuy(x));
//                         SetCost(x);
//                     }).AddTo(this);
//             }
//             else if (upgrade.type == UpgradeMessage.Type.OfflineMoney)
//             {
//                 observableLevel = DataController.PlayerData.Value.ObserveEveryValueChanged(x => x.OfflineMoneyLevel);

//                 CurrencyManager.OfflineMoneyCost.ObserveEveryValueChanged(x => x.Value)
//                     .Subscribe(x =>
//                     {
//                         SetLocked(!CurrencyManager.CheckCanBuy(x));
//                         SetCost(x);
//                     }).AddTo(this);
//             }

//             SetLocked(level > limit || !CurrencyManager.CheckCanBuy(upgrade.type));

//             observableLevel.Subscribe(x => { SetLevelValue(x + 1); }).AddTo(this);

//             observableLevel.Where(x => limit > 0)
//                 .Where(x => x >= limit)
//                 .Subscribe(x => { SetLocked(true); }).AddTo(this);

//             DataController.PlayerData.Value.ObserveEveryValueChanged(x => x.Coins)
//                 .Subscribe(x => { SetLocked(level > limit || !CurrencyManager.CheckCanBuy(upgrade.type)); }).AddTo(this);
//         }

//         public UpgradeButton SetCost(int cost)
//         {
//             costText.text = $"{cost}";

//             return this;
//         }

//         public UpgradeButton SetLevelValue(int level)
//         {
//             levelText.text = $"{level}";
//             this.level = level;

//             return this;
//         }

//         public UpgradeButton SetWatchRV(bool watch)
//         {
//             if (adImage == null)
//             {
//                 Debug.LogError("upgrade button: missing ad image");
//                 return this;
//             }

//             adImage.SetActive(watch);

//             coinImage.gameObject.SetActive(!watch);
//             costText.gameObject.SetActive(!watch);

//             return this;
//         }

//         public UpgradeButton SetLocked(bool locked)
//         {
//             // if (useRV)
//             //     return this;

//             lockImage.gameObject.SetActive(locked);
//             button.interactable = !locked;

//             return this;
//         }
//     }
// }